Follow the instructions in pdn_lab01.pdf

If you need a linux system for development, use the Vagrantfile included in /VAGRANT. Follow the video instructions of setting up and using Vagrant posted on Canvas. Once the box is running perform a git clone/pull from inside the box.

To build and run this code type "make." 

If the benchmark and verification is taking too much time you can modify the top of the makefile to sweep through fewer sizes. Note, that you are still responsible for speeding up the larger sizes.

Everytime you create a variant of the transpose: create a new file, add that file to your git repo and modify op2_dispatch_vars.sh accordingly. Commit and push often on git.
