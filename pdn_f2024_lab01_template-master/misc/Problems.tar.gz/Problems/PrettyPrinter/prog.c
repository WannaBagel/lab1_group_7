#include <stdio.h>
#include <stdlib.h>

void pretty_print(int m, int n, int rs, int cs, char *mem) {
    printf("%d\\%d (j-->)\n", m, n);
    // print column 
    printf("(i)\\ ");
    for (int j = 0; j < n; ++j) {
        printf("%02d", j); 
        if (j != n - 1) {
            printf("_");   
        }
    }
    printf("\n");

    for (int i = 0; i < m; ++i) {
        printf("|%02d|", i); 
        for (int j = 0; j < n; ++j) {
            int index = i * rs + j * cs;
            printf(" %c ", mem[index]); 
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {
    FILE *infile = fopen(argv[1], "r");
    int m, n, rs, cs, mem_size;
    fscanf(infile, "%d %d %d %d %d", &m, &n, &rs, &cs, &mem_size);


    char *mem = (char *)malloc(mem_size * sizeof(char));
    for (int i = 0; i < mem_size; ++i) {
        fscanf(infile, " %c", &mem[i]);
    }

    fclose(infile);

    FILE *outfile = fopen(argv[2], "w");
    stdout = outfile;

    pretty_print(m, n, rs, cs, mem);
    fclose(outfile);
    free(mem);
    
    return 0;
}
