#include <stdio.h>
#include <stdlib.h>

void print_row(int m, int rs) {
    printf("ROW_STARTS: ");
    for (int i = 0; i < m; ++i) {
        printf("V");
        for (int j = 1; j < rs; ++j) {
            printf("   "); 
        }
        printf("  "); 
    }
    printf("\n");
}

void print_mem(char *mem, int mem_size) {
    printf("MEMORY:     ");
    for (int i = 0; i < mem_size; ++i) {
        printf("%c", mem[i]);
        if (i != mem_size - 1) {
            printf(", ");
        }
    }
    printf("\n");
}

void print_col(int n, int cs) {
    printf("COL_STARTS: ");
    for (int i = 0; i < n; ++i) {
        printf("^");
        for (int j = 1; j < cs; ++j) {
            printf("    "); 
        }
        printf("  "); 
    }
    printf("\n");
}

int main(int argc, char *argv[]) {
    // Open the input file
    FILE *infile = fopen(argv[1], "r");
 
    int m, n, rs, cs, mem_size;
    // scan in elements
    fscanf(infile, "%d %d %d %d %d", &m, &n, &rs, &cs, &mem_size);

    // allocate mem
    char *mem = (char *)malloc(mem_size * sizeof(char));
    for (int i = 0; i < mem_size; ++i) {
        fscanf(infile, " %c", &mem[i]);
    }

    fclose(infile);

    FILE *outfile = fopen(argv[2], "w");

    stdout = outfile;

    printf("M: %d\n", m);
    printf("N: %d\n", n);
    printf("RS: %d\n", rs);
    printf("CS: %d\n", cs);
    printf("MEMORY[%d] = {", mem_size);
    for (int i = 0; i < mem_size; ++i) {
        printf("'%c'", mem[i]);
        if (i != mem_size - 1) {
            printf(",");
        }
    }
    printf("}\n");

    print_row(m, rs);
    print_mem(mem, mem_size);
    print_col(n, cs);

    fclose(outfile);
    free(mem);
    return 0;
}
