#include <stdio.h>
#include <stdlib.h>

void pretty_block_print(int mb, int nb, int i, int j, int rs, int cs, char *mem, int m, int n) {
    printf("%d\\%d (j-->)\n", mb, nb);
    printf("(i) \\ ");
    for (int col = 0; col < nb; ++col) {
        printf("%02d", col); 
        if (col != nb - 1) {
            printf("_");
        }
    }
    printf("\n");

    // print row
    for (int row = 0; row < mb; ++row) {
        if (row == 0) {
            printf("V ");
        } else {
            printf("  ");
        }

        // print row index
        printf("|%02d|", row);

        // print values
        for (int col = 0; col < nb; ++col) {
            int row_matrix = i + row;
            int col_matrix = j + col;
            int index = row_matrix * rs + col_matrix * cs;
            printf(" %c ", mem[index]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {
    FILE *infile = fopen(argv[1], "r");

    int m, n, rs, cs, mb, nb, i, j, mem_size;
    fscanf(infile, "%d %d %d %d %d %d %d %d %d", &m, &n, &rs, &cs, &mb, &nb, &i, &j, &mem_size);

    // allocate mem
    char *mem = (char *)malloc(mem_size * sizeof(char));

    for (int idx = 0; idx < mem_size; ++idx) {
        fscanf(infile, " %c", &mem[idx]);
    }

    fclose(infile);

    FILE *outfile = fopen(argv[2], "w");
    stdout = outfile;

    pretty_block_print(mb, nb, i, j, rs, cs, mem, m, n);

    fclose(outfile);
    free(mem); 
    return 0;
}
